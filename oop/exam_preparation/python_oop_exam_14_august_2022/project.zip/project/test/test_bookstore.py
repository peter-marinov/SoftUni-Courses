import unittest

from project.bookstore import Bookstore


class TestBookStore(unittest.TestCase):
    def setUp(self):
        self.bookstore = Bookstore(10)

    def test_correct_initializing(self):
        self.assertEqual(10, self.bookstore.books_limit)
        self.assertEqual({}, self.bookstore.availability_in_store_by_book_titles)
        self.assertEqual(0, self.bookstore._Bookstore__total_sold_books)

    def test_books_limit_with_value_zero_expect_value_error(self):
        with self.assertRaises(ValueError) as ve:
            bookstore = Bookstore(0)

        self.assertEqual(f"Books limit of 0 is not valid", str(ve.exception))

    def test_book_limit_with_value_bigger_than_zero(self):
        self.assertEqual(10, self.bookstore.books_limit)

    def test_len_of_books(self):
        self.bookstore.availability_in_store_by_book_titles = {
            'some_name1': 1,
            'some_name2': 2
        }
        self.assertEqual(3, len(self.bookstore))

    def test_receive_book_when_there_is_no_space(self):
        self.bookstore.availability_in_store_by_book_titles = {
            'some_name1': 5,
            'some_name2': 5
        }

        with self.assertRaises(Exception) as ex:
            self.bookstore.receive_book('book', 2)

        self.assertEqual("Books limit is reached. Cannot receive more books!", str(ex.exception))

    def test_receive_new_book_when_there_is_space(self):
        self.bookstore.availability_in_store_by_book_titles = {
            'some_name1': 5
        }

        result = self.bookstore.receive_book('book', 3)

        self.assertEqual(8, len(self.bookstore))
        self.assertEqual({'some_name1': 5, 'book': 3}, self.bookstore.availability_in_store_by_book_titles)
        self.assertEqual("3 copies of book are available in the bookstore.", result)

    def test_receive_existing_book_when_there_is_space(self):
        self.bookstore.availability_in_store_by_book_titles = {
            'some_name1': 5
        }

        result = self.bookstore.receive_book('some_name1', 3)

        self.assertEqual(8, len(self.bookstore))
        self.assertEqual({'some_name1': 8}, self.bookstore.availability_in_store_by_book_titles)
        self.assertEqual("8 copies of some_name1 are available in the bookstore.", result)


    def test_sell_book_which_not_available(self):
        self.bookstore.availability_in_store_by_book_titles = {
            'some_name1': 5
        }
        with self.assertRaises(Exception) as ex:
            self.bookstore.sell_book('book', 3)

        self.assertEqual("Book book doesn't exist!", str(ex.exception))

    def test_sell_book_when_not_enough_copies(self):
        self.bookstore.availability_in_store_by_book_titles = {
            'some_name1': 5
        }

        with self.assertRaises(Exception) as ex:
            self.bookstore.sell_book('some_name1', 6)

        self.assertEqual("some_name1 has not enough copies to sell. Left: 5", str(ex.exception))

    def test_sell_book_when_it_is_possible(self):
        self.bookstore.availability_in_store_by_book_titles = {
            'some_name1': 5
        }
        result = self.bookstore.sell_book('some_name1', 3)

        self.assertEqual(2, self.bookstore.availability_in_store_by_book_titles['some_name1'])
        self.assertEqual(3, self.bookstore._Bookstore__total_sold_books)
        self.assertEqual("Sold 3 copies of some_name1", result)

    def test_str_method_output(self):
        self.bookstore.availability_in_store_by_book_titles = {
            'some_name1': 5
        }
        self.bookstore.sell_book('some_name1', 3)
        self.bookstore.receive_book('book', 3)

        expected_result = []
        expected_result.append('Total sold books: 3')
        expected_result.append('Current availability: 5')
        expected_result.append(' - some_name1: 2 copies')
        expected_result.append(' - book: 3 copies')

        self.assertEqual('\n'.join(expected_result), str(self.bookstore))


if __name__ == '__main__':
    unittest.main()